""" Utilities for testing
"""

from unittest import TestCase


assert_raises = TestCase().assertRaises
